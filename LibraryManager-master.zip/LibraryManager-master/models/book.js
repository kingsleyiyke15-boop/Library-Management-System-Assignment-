const mongoose = require("mongoose")

const bookSchema = new mongoose.Schema({
    title: {type: String, required: true},

    Isbn: {type: String, unique: true},

    //Relationship
    authors: [{type: mongoose.Schema.Types.ObjectId, ref: "author"}],

    status: {type: String,
        enum: ["IN", "OUT"],
        default: "IN"
    },

    borrowedBy: {type: mongoose.Schema.Types.ObjectId, ref: "student"},

    IssuedBy: {type: mongoose.Schema.Types.ObjectId, ref: "attendant"},

    returnDate: {type: Date, dafault: null}
},
{timestamps: true});